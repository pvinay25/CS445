import java.util.ArrayList;
/**
 * NewsFeed is the client class.
 * 
 * @author Pavithra Vinay
 * @version 06/04/2016
 */
public class NewsFeed
{
    
    private ArrayList<Post> posts;
     
    public NewsFeed(){
         posts = new ArrayList<Post>();
    }
       
    public void addPost(Post post){
        posts.add(post);        
    }
    
    public void show(){
        int i = 1;   //for display purposes only
        for(Post post: posts){
            
            System.out.println();
            System.out.println("Displaying post number: "+i);
            System.out.println();
            post.display();
            i++;
        }
    }
    
    public static void main(String[] args){
        
        String author = "Pavithra";
        
        Post post = new Post(author);
        
        post.getTimestamp();        
        
        EventPost eventPost = new EventPost("Birthday",author);       
       
        CommentedPost commentedPost = new CommentedPost(author);       
        
        commentedPost.unlike();        
        
        commentedPost.like();         
       
        commentedPost.like();       
        
        commentedPost.addComments("Wow! looks like a great place");       
        
        commentedPost.like();        
        
        commentedPost.addComments("Way to spend Looooooong weekend!! ");        
       
        commentedPost.unlike();   
        
        MessagePost messagePost = new MessagePost("It's a beautiful day!", author);       
        
        PhotoPost photoPost = new PhotoPost(author,"pav.jpg","Pavithra Vinay");         
       
        System.out.println("** Passing Post object **");
        NewsFeed newsFeed = new NewsFeed();
        newsFeed.addPost(post);
        newsFeed.show();
        System.out.println();
        System.out.println();
        
        System.out.println("** Passing CommentedPost object **");
        newsFeed.addPost(commentedPost);
        commentedPost.like();
        newsFeed.show();
        System.out.println();
        System.out.println();
        
        System.out.println("** Passing EventPost object **");
        newsFeed.addPost(eventPost);
        newsFeed.show();
        System.out.println();
        System.out.println();
        
        System.out.println("** Passing MessagePost object **");
        newsFeed.addPost(messagePost);
        messagePost.like();
        newsFeed.show();
        System.out.println();System.out.println();
        
        System.out.println("** Passing PhotoPost object **");
        newsFeed.addPost(photoPost);
        photoPost.like();
        photoPost.like();
        newsFeed.show();    
        
    }    
}
