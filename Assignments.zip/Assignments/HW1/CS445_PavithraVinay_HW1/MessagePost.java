
/**
 * MessagePost class is used to capture messages.
 * 
 * @author Pavithra Vinay
 * @version 06/04/2016
 */
public class MessagePost extends CommentedPost
{
    private String message;
    
    public MessagePost(String message, String author){
        super(author);
        this.message = message;
    }
    
    public String getText(){
        return message;
    }
    
    public void display(){
        super.display();
        System.out.println("Message: " + message);
    }
        
}
