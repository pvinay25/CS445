import java.util.ArrayList;
/**
 *CoomentedPost class is used to add comments and likes.
 * 
 * @author Pavithra Vinay
 * @version 06/04/2016
 */

public class CommentedPost extends Post
{
    private int likes;
    private ArrayList<String> comments;
    
    
    public CommentedPost(String author){
        super(author);
        likes = 0;
        comments = new ArrayList<String>();
    }
    
    public void like(){
        likes++;
    }
    
    public void unlike(){
        if(likes > 0){
            likes--;
        }
        else{
            System.err.println("Likes cannot be less than zero.");
        }
        
    }
    
    public void addComments(String comment){
        comments.add(comment);
    }
    
    public void display(){
        super.display();
        System.out.println("Number of likes: " + likes);
        for(String comment:comments){
            System.out.println("Comment added: "+comment);
        }
    }
    
    
    
}


