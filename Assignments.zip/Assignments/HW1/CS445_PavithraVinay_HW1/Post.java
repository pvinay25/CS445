import java.util.Date;
import java.text.Format;
import java.text.SimpleDateFormat;
/**
 * Class Post is the parent class for NewsFeed Application.
 *
 * @author Pavithra Vinay 
 * @version 06/04/2016
 */
public class Post
{
    private String username ;
    private long timestamp;
    
    public Post(String author){
        
        username = author;
        timestamp = System.currentTimeMillis();
        
    }
    
    public long getTimestamp(){
        return timestamp;
    }
    
    public String convertTime(long timestamp){
        Date date = new Date(timestamp);
        Format format = new SimpleDateFormat("yyyy MM dd HH:mm:ss.SSS");
        return format.format(date);
    }
    
    public void display(){
        System.out.println("Username: "+ username);
        System.out.println("Time posted: " + this.convertTime(timestamp));
    }
    
    public String toString() {
		return "Post [username=" + username + ", timestamp=" + timestamp + "]";
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Post other = (Post) obj;
		if (timestamp != other.timestamp)
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
      
}
