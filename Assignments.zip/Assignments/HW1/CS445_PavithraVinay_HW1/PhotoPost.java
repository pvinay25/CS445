
/**
 * PhotoPost class is used to capture filename and caption of the photo posts.
 * 
 * @author Pavithra Vinay 
 * @version 06/04/2016
 */
public class PhotoPost extends CommentedPost
{
    private String filename;
    private String caption;
    
    public PhotoPost(String author, String filename, String caption){
        super( author);
        this.filename = filename;
        this.caption = caption;
        
    }
    
    public String getImageFile(){
        return filename;
    }
    
    public String getCaption(){
        return caption;
    }
    
    public void display(){
        super.display();
        System.out.println("File name: " + filename);
        System.out.println("Caption: " + caption);
    }
}
