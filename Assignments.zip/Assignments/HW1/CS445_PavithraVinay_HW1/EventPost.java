
/**
 * EventPost is a subclass of Post.
 * 
 * @author Pavithra Vinay
 * @version 06/04/2016
 */
public class EventPost extends Post
{
   private String eventType;
   
   public EventPost(String eventType, String author){
       super(author);
       this.eventType = eventType;
    }
    
    public void display(){
        super.display();
        System.out.println("Event Type: " + eventType);
        }
    
}
