
public class MoneyDriver {

	public static void main(String[] args) {

		Money m1 = new Money(500.00);
		Money m2 = new Money(m1);
		Money m3 = new Money(10.02);
		Money m4 = new Money(10.88);
		Money m5 = new Money(m3);

		System.out.println("The current amount is " + m1);
		Money sum = m1.add(m3);
		System.out.println("Adding " + m3 + " gives " + sum);
		Money difference = sum.subtract(m4);
		System.out.println("Subtracting " + m4 + " gives " + difference);

		m3.compareTo(m5);
		m4.compareTo(m3);
	}

	public void compareObjects(Money money) {

	}
}
