
public class CreditCard {

	private Money balance;
	private Money creditLimit;
	private Person owner;

	public CreditCard(Person newCardHolder, Money limit) {

		owner = newCardHolder;
		creditLimit = limit;
		balance = new Money(0);
	}

	public Money getBalance() {
		return balance;
	}

	public Money getCreditLimit() {
		return creditLimit;
	}

	public String getOwner() {
		return owner.toString();
	}

	public void charge(Money amount) {
		System.out.println("Attempt to charge " + amount);
		Money money = balance.add(amount);
		if (((money.compareTo(creditLimit)) <= 0)) {
			this.balance = balance.add(amount);
			System.out.println("Charge: " + amount);

		} else {
			System.out.println("Credit limit is exceeded");
		}
		System.out.println("Balance: " + this.balance);

	}

	public void payment(Money amount) {
		System.out.println("Attempt to pay: " + amount);
		this.balance = balance.subtract(amount);
		System.out.println("Payment: " + amount);
		System.out.println("Balance: " + this.balance);
	}

	@Override
	public String toString() {
		return "Balance: " + balance + "\nCredit Limit: " + creditLimit;
	}

}
