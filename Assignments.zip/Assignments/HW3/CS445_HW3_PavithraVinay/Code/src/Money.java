import java.util.regex.Pattern;

public class Money {

	private long dollars;
	private long cents;

	public Money() {

	}

	public Money(double amount) {
		if (amount < 0) {
			System.err.println("Negative amount is not allowed, assigning default value 0.\n");
		} else {
			long newCents = Math.round(amount * 100);
			dollars = newCents / 100;
			cents = newCents % 100;
		}
	}

	public Money(long dollars, long cents) {
		super();
		this.dollars = dollars;
		this.cents = cents;
	}

	// Copy constructor
	public Money(Money otherObject) {
		this(otherObject.getDollars(), otherObject.getCents());

	}

	public long getDollars() {
		return dollars;
	}

	public void setDollars(long dollars) {
		this.dollars = dollars;
	}

	public long getCents() {
		return cents;
	}

	public void setCents(long cents) {
		this.cents = cents;
	}

	public Money add(Money otherAmount) {
		Money money = new Money(0);
		if ((this.dollars + this.cents) > 0) {
			if ((this.cents + otherAmount.cents) > 100) {
				money.cents = this.cents + otherAmount.cents;
				money.cents = money.cents % 100;
				money.dollars = this.dollars + otherAmount.dollars + 1;

			} else {
				money.cents = this.cents + otherAmount.cents;
				money.dollars = this.dollars + otherAmount.dollars;

			}
		}
		money.cents = this.cents + otherAmount.cents;
		money.cents = money.cents % 100;
		money.dollars = this.dollars + otherAmount.dollars;
		return money;
	}

	public Money subtract(Money otherAmount) {
		Money money = new Money(0);
		if (this.cents < otherAmount.cents) {
			this.cents = this.cents + 100;
			this.dollars = this.dollars - 1;

			if (this.dollars < otherAmount.dollars) {
				money.dollars = this.dollars - otherAmount.dollars + 1;
				money.cents = 100 - (this.cents - otherAmount.cents);
				return money;
			} else {
				money.dollars = this.dollars - otherAmount.dollars;
				money.cents = this.cents - otherAmount.cents;
				return money;
			}
		} else if (this.dollars < otherAmount.dollars) {

			money.dollars = this.dollars - otherAmount.dollars + 1;
			money.cents = 100 - (this.cents - otherAmount.cents);
			return money;
		}

		money.dollars = this.dollars - otherAmount.dollars;
		money.cents = this.cents - otherAmount.cents;
		return money;

	}

	public int compareTo(Money otherObject) {

		int value;
		if (this.dollars < otherObject.dollars) {
			value = -1;
			System.out.println(this.toString() + " does not equal " + otherObject.toString());
		} else if (this.cents < otherObject.cents) {
			value = -1;
			System.out.println(this.toString() + " does not equal " + otherObject.toString());
		} else if (this.dollars > otherObject.dollars) {
			value = 1;
			System.out.println(this.toString() + " does not equal " + otherObject.toString());
		} else if (this.cents > otherObject.cents) {
			value = 1;
			System.out.println(this.toString() + " does not equal " + otherObject.toString());
		} else {
			value = 0;
			System.out.println(this.toString() + " equal " + otherObject.toString());
		}
		return value;
	}

	public boolean equals(Money otherObject) {
		if ((this.dollars == otherObject.dollars) && (this.cents == otherObject.cents)) {
			return true;
		} else
			return false;
	}

	public String toString() {

		if (this.cents < 10) {
			return "$" + dollars + "." + '0' + cents;
		}
		return "$" + dollars + "." + String.format("%2d", cents);
	}

}
