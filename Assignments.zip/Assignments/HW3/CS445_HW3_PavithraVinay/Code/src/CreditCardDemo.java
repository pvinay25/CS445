
public class CreditCardDemo {
	public static void main(String[] args) {

		Address address1 = new Address("237J Harvey Hall", "Menomonie", "WI ", "60616");
		Person person1 = new Person("Diane", "Christie", address1);
		System.out.println(person1);
		Money money = new Money(1000.0);
		Money money2 = new Money(200);
		Money money3 = new Money(10.02);
		Money money4 = new Money(25);
		Money money5 = new Money(990);
		CreditCard card = new CreditCard(person1, money);
		System.out.println(card);
		card.charge(money2);
		card.charge(money3);
		card.payment(money4);
		card.charge(money5);
	}

}
