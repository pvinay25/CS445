
Author - Pavithra Vinay
Date - 06/30/2016


Instructions to run the code:

1. Code can be found in ‘Code’ folder.
2. Export this folder to eclipse.
3. Open MoneyDriver.java file and click run to see the output.
4. Open CreditCardDemo.java file and click run to see the output.

Note - In CreditCardDemo.java output, you can see comparison texts in between as I have used compateTo() method to perform the operation.