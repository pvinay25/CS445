
public class InvalidShiftException extends Exception {

	public InvalidShiftException() {
		super("InvalidShiftException: Invalid shift, it should be either 1 or 2.");

	}

}
