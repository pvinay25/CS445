import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ProductionWorkerTest {

	// an ArrayList to store objects of type ProductionWorker
	protected ArrayList<ProductionWorker> workersList;

	public static void main(String[] args) {

		ArrayList<ProductionWorker> workersList = new ArrayList<>();

		Scanner input = new Scanner(System.in);
		int i = 1;

		// prompt and sample data for user
		System.out.println("Please Enter Production worker details in below format:");
		System.out.println("name,number,shift,hourlyPayRate");
		System.out.println("Example: Bob,678-G,1,67.89");
		System.out.println("Enter details of worker1: ");

		// assign data to instance variables using StringTokenizer and add
		// objects to ArrayList
		do {
			String productionWorker = input.nextLine();
			boolean validInput = validateUserInput(productionWorker);

			if (validInput) {
				StringTokenizer workerData = new StringTokenizer(productionWorker, ",");

				String name = workerData.nextToken();
				String number = workerData.nextToken();
				String shift = workerData.nextToken();
				String payRate = workerData.nextToken();

				ProductionWorker pw1 = null;
				try {
					pw1 = new ProductionWorker(name, number, Integer.parseInt(shift), Double.parseDouble(payRate));
					workersList.add(pw1);

					i++;
					if (i < 4) {
						System.out.println("Enter details of worker" + i + ":");

					}
				} catch (NumberFormatException | InvalidNameException | InvalidEmployeeNumberException
						| InvalidShiftException | InvalidPayRateException e) {

					System.out.println("Invalid input.Please try again.");
				}
			}

		} while (workersList.size() <= 2);

		// display entered data
		System.out.println("Successfully created three production workers.");
		for (ProductionWorker worker : workersList) {
			System.out.println(worker);

		}

		WriteEmployeeDataToFile writeData = new WriteEmployeeDataToFile();
		writeData.writeToFile(workersList, "employees.dat");

		try {
			ReadEmployeeDataFromFile readData = new ReadEmployeeDataFromFile();
			readData.readDataFromFile("blah.dat");
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}

	// validate number of arguments user inputs
	public static boolean validateUserInput(String userInput) {
		String[] args = userInput.split(",");
		if (args.length != 4) {
			System.out.println("Invalid number of arguments, please try again");
			return false;
		}

		else
			return true;
	}

}
