
public class InvalidEmployeeNumberException extends Exception {

	public InvalidEmployeeNumberException() {
		super("InvalidEmployeeNumberException: Invalid Employee Number.");
	}

	public InvalidEmployeeNumberException(String message) {
		super("InvalidEmployeeNumberException: " + message);

	}

}
