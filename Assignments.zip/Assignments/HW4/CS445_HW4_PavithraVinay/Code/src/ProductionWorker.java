
public class ProductionWorker extends Employee {

	private int shift;
	private double hourlyPayRate;

	// default constructor
	public ProductionWorker() {
		System.out.println("Setting shift to default Day shift.");
		this.shift = 1;
		System.out.println("Setting hourly payrate to default of 0. ");
		this.hourlyPayRate = 0.0;
	}

	/*
	 * overloaded constructor
	 * 
	 * @exception InvalidNameException if an invalid name is entered .
	 * 
	 * @exception InvalidEmployeeNumberException if an invalid number is entered
	 * 
	 * @exception InvalidShiftException if an invalid shift is entered .
	 * 
	 * @exception InvalidPayRateException if an invalid pay rate is entered .
	 */
	public ProductionWorker(String name, String number, int shift, double hourlyPayRate) throws InvalidNameException,
			InvalidEmployeeNumberException, InvalidShiftException, InvalidPayRateException {
		super(name, number);

		try {
			setShift(shift);
		} catch (InvalidShiftException e) {
			System.out.println(e.getMessage());
			throw e;
		}

		try {
			setHourlyPayRate(hourlyPayRate);
		} catch (InvalidPayRateException e) {
			System.out.println(e.getMessage());
			throw e;
		}

	}

	public int getShift() {
		return shift;
	}

	/*
	 * validate employee shift
	 * 
	 * @exception InvalidShiftException if an invalid shift is entered .
	 */

	public void setShift(int shift) throws InvalidShiftException {
		if (shift != 1 && shift != 2) {
			throw new InvalidShiftException();
		}
		this.shift = shift;
	}

	public double getHourlyPayRate() {
		return hourlyPayRate;
	}

	/*
	 * validate employee hourlyPayRate
	 * 
	 * @exception InvalidPayRateException if an invalid pay rate is entered .
	 */
	public void setHourlyPayRate(double hourlyPayRate) throws InvalidPayRateException {
		if (hourlyPayRate <= 0) {
			throw new InvalidPayRateException();
		}
		this.hourlyPayRate = hourlyPayRate;
	}

	public String toString() {
		return super.toString() + " [shift=" + shift + ", hourlyPayRate=" + hourlyPayRate + "]";
	}

}
