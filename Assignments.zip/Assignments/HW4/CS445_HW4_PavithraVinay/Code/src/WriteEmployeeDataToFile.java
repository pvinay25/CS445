import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class WriteEmployeeDataToFile {

	private FileOutputStream fos;
	private ObjectOutputStream oos;

	public WriteEmployeeDataToFile() {

	}

	// @exception FileNotFoundException
	public void writeToFile(ArrayList<ProductionWorker> workerList, String filename) {
		try {

			fos = new FileOutputStream(filename, false);
			oos = new ObjectOutputStream(fos);
			for (ProductionWorker worker : workerList) {
				oos.writeUTF(worker.toString());
			}

			System.out.println(
					"Successfully written to employees.dat file, please check project folder to see the file.");
			System.out.println();

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				oos.close();
			} catch (IOException e) {
				e.getMessage();
			}
		}
	}
}
