public class Test {
	public static void main(String[] args) {

		try {
			Employee emp1 = new Employee("&&Bob", "897");
		} catch (InvalidNameException | InvalidEmployeeNumberException e1) {

		}
		try {
			Employee emp2 = new Employee("Bob", "67879");
		} catch (InvalidNameException | InvalidEmployeeNumberException e1) {

		}
		try {
			Employee emp3 = new Employee("Bob", "A7_79");
		} catch (InvalidNameException | InvalidEmployeeNumberException e1) {

		}
		try {
			Employee emp4 = new Employee("Bob", "679-N");
		} catch (InvalidNameException | InvalidEmployeeNumberException e1) {

		}

		try {
			ProductionWorker worker1 = new ProductionWorker("Bob", "768-C", 7, 45.78);
		} catch (InvalidNameException | InvalidEmployeeNumberException | InvalidShiftException
				| InvalidPayRateException e) {

		}

		try {
			ProductionWorker worker2 = new ProductionWorker("Bob", "768-C", 1, -45.78);
		} catch (InvalidNameException | InvalidEmployeeNumberException | InvalidShiftException
				| InvalidPayRateException e) {

		}

	}
}
