import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ReadEmployeeDataFromFile {

	private FileInputStream fis;
	private ObjectInputStream ois;
	private ArrayList<String> employeeList;

	public ReadEmployeeDataFromFile() {

	}

	// @exception FileNotFoundException if file not found.
	public void readDataFromFile(String filename) {

		employeeList = new ArrayList<>();
		try {

			fis = new FileInputStream(filename);
			ois = new ObjectInputStream(fis);

			while (fis.available() > 0) {
				String employeeRecord = ois.readUTF();
				employeeList.add(employeeRecord);
			}
			System.out.println("Successfully read the input file.");
			System.out.println();
			for (String employee : employeeList) {
				System.out.println(employee);
			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());

		} finally {
			try {
				ois.close();
			} catch (IOException e) {

				System.out.println(e.getMessage());
			}
		}

	}
}