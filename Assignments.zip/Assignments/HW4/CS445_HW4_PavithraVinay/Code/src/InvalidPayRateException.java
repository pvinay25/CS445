
public class InvalidPayRateException extends Exception {

	public InvalidPayRateException() {
		super("InvalidHourlyPayException: Hourly pay cannot be negative or zero.");
	}

	public InvalidPayRateException(String message) {
		super("InvalidHourlyPayException: " + message);
	}
}
