
public class InvalidNameException extends Exception {

	public InvalidNameException() {
		super("InvalidNameException: The name you have entered has special characters/digits.");
	}

	public InvalidNameException(String message) {
		super("InvalidNameException: " + message);
	}

}
