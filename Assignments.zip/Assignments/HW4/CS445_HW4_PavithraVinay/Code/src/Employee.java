import java.sql.Date;
import java.util.regex.Pattern;

public class Employee {
	private String name;
	private String number;
	private Date hireDate;

	// no argument constructor
	public Employee() {

	}

	// overloaded constructor - throws exceptions
	public Employee(String name, String number) throws InvalidNameException, InvalidEmployeeNumberException {
		setHireDate();
		try {
			setName(name);
		} catch (InvalidNameException e) {
			System.out.println(e.getMessage());
			throw e;
		}
		try {
			setNumber(number);
		} catch (InvalidEmployeeNumberException e) {
			System.out.println(e.getMessage());
			throw e;
		}

	}

	public String getName() {
		return name;
	}

	/*
	 * employee name validation
	 * 
	 * @exception InvalidNameException if an invalid name is entered .
	 */
	public void setName(String name) throws InvalidNameException {
		if (name == null || name.trim().isEmpty()) {
			throw new InvalidNameException("Name cannot be left blank.");
		}

		else if (!Pattern.matches("[^;&#/%=|+\\\\\"<>[0-9]]+", name)) {
			throw new InvalidNameException();
		} else

			this.name = name;
	}

	public String getNumber() {
		return number;
	}

	/*
	 * employee ID validation
	 * 
	 * @exception InvalidEmployeeNumberException if an invalid employee number
	 * is entered .
	 */
	public void setNumber(String id) throws InvalidEmployeeNumberException {

		// validate length
		if (id.length() != 5) {
			throw new InvalidEmployeeNumberException("Employee ID must be of 5 digits. Your length:" + id.length());
		}

		// validate numeric characters
		for (int i = 0; i <= 2; i++) {
			if (!id.substring(i, i + 1).matches("[0-9]")) {
				throw new InvalidEmployeeNumberException(
						"First 3 characters of Employee Number should be between 0 to 9. You have entered " + "'"
								+ id.substring(i, i + 1) + "'" + " at position " + (i + 1));
			}
		}

		// validate hyphen
		if (!id.substring(3, 4).equals("-")) {
			throw new InvalidEmployeeNumberException(
					"Employee number is in incorrect format, it should have a hyphen.");
		}

		// validate alpha character
		if (!id.substring(4, 5).matches("[a-mA-M]")) {
			throw new InvalidEmployeeNumberException(
					"Last character of Employee number should be an alpha character between A to M. You have entered "
							+ id.substring(4, 5) + ".");
		}
		this.number = id;
	}

	public Date getHireDate() {
		return hireDate;
	}

	// set hireDate to current date
	public void setHireDate() {
		this.hireDate = new Date(System.currentTimeMillis());
	}

	public String toString() {
		return "Employee [name=" + name + ", number=" + number + ", hireDate=" + hireDate + "]";
	}

}
