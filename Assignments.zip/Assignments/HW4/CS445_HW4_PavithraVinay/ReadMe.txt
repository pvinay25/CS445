Instructions to run:

1.Code can be found in Code folder. 
2.Export this into eclipse.
3. Open Test.java file and run to see InvalidNameException, InvalidEmployeeNumberException, InvalidShiftException and InvalidPayRateException.
4. Open ProductionWorkerTest.java to provide user input. Application will validate your input and accepts only if is valid, else exception will be thrown. It will accept 3 valid inputs. You can also find file not found exception demonstrated in the same .java file.

 
Author - Pavithra Vinay
Date - 06/30/2016