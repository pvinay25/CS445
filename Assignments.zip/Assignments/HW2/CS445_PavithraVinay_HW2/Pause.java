
/**
 * class Pause
 * This is to implement wait method.
 * 
 * @author Pavithra Vinay
 * @version 06/09/2016
 */

public class Pause {

	public static void wait(double wait) {
		long waitTime = (long) (wait * 1000);
		try {
			Thread.sleep(waitTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
