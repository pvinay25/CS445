import java.awt.Graphics;
import javax.swing.JApplet;

/**
 * Write a description of class TortoiseRacerClient here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TortoiseRacerClient extends JApplet
{
   private TortoiseRacer t;
	private TortoiseRacer t2;

	public void init() {
		t = new TortoiseRacer("Tortoise", 25, 25);
		t2 = new TortoiseRacer("Tortoise2", 25, 100);

	}

	public void paint(Graphics g) {

		for (int i = 0; i < getWidth(); i++) {

			t.draw(g);
			t.move(2);
			Pause.wait(0.03);
			t2.draw(g);
			t2.move(3);
			Pause.wait(0.03);
			g.clearRect(0, 0, getWidth(), getHeight());

		}

	}

}

