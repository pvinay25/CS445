import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
/**
 * Write a description of class TortoiseRacer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TortoiseRacer extends Animal implements Movable
{
    public TortoiseRacer() {
		super();
	}

	public TortoiseRacer(String rId, int rX, int rY) {
		super(rId, rX, rY);
	}

	public void draw(Graphics g) {
		int startX = getX();
		int startY = getY();
		g.setColor(this.getRandomColor());
		g.fillOval(startX, startY, 25, 15); // 25,15
		g.fillOval(startX + 20, startY + 5, 15, 10);
		g.clearRect(startX, startY + 11, 35, 4);
		g.setColor(this.getRandomColor());
		g.fillOval(startX + 3, startY + 10, 5, 5);
		g.fillOval(startX + 17, startY + 10, 5, 5);
	}

	public void move(int speed) {
		setX(getX() + speed);

	}

	public Color getRandomColor() {
		Random random = new Random();
		int r = random.nextInt(255);
		int g = random.nextInt(255);
		int b = random.nextInt(255);
		return new Color(r, g, b);

	}

}
