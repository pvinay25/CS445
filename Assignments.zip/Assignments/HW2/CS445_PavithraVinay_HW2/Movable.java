
/**
 * Write a description of interface Movable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Movable {

	// int FAST = 5;
	// int SLOW = 1;

	void move(int speed);

}

