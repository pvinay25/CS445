import java.sql.Date;
import java.util.ArrayList;

public interface IProductInventory {

	boolean addItemsToInventory(int productId, int quantity, Date expirationDate);
	boolean removeItemsFromInventory(int itemId, int quantity);
	boolean consumeItemsFromInventory(int productId, int quantity);
	boolean removeItemsFromInventory(int itemId);
	ArrayList<ProductInventory> retrieveAllItems();
	//Return list of items which have reached minimum quantity in inventory/Fridge
	ArrayList<ProductInventory> retrieveThresholdItems();
	
}
