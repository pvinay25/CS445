
public enum ProductStatus {

	HIGH,
	MEDIUM,
	LOW;
}
