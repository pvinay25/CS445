import java.util.ArrayList;

public interface IShoppingList {
	
	//Method to re-order expiredProducts;
	ArrayList<ExpiredProduct> restockExpiredProducts();
	
	//Method to re-stock inventory to fill products up to ThresholdQuantity
	ArrayList<ProductInventory> restockInventory();
	
	//Method to re-stock inventory for products of specific Priority/Status
	ArrayList<ProductInventory> restockInventory(ProductStatus productStatus);
	
	//Method to res-stock inventory for products of specific category
	ArrayList<ProductInventory> restockInventory(ProductCategory productCategory);

}
