import java.util.ArrayList;

public class ShoppingList implements IShoppingList {

	@Override
	public ArrayList<ExpiredProduct> restockExpiredProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ProductInventory> restockInventory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ProductInventory> restockInventory(ProductStatus productStatus) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ProductInventory> restockInventory(ProductCategory productCategory) {
		// TODO Auto-generated method stub
		return null;
	}

}
