import java.sql.Date;
import java.util.ArrayList;

class ExpiredProduct extends Product implements IExpiredProduct {

	private ArrayList<ProductInventory> expiredItemList; // Datastore to hold
															// list of expired
															// Products
	private ArrayList<ProductInventory> allItemList; // Datastore to hold list
														// of all product items.

	public ExpiredProduct() {
		allItemList = new ArrayList<ProductInventory>();
		IProductInventory productInventory = new ProductInventory();
		allItemList = productInventory.retrieveAllItems();
	}

	// This method returns a list of all the expired items from the inventory;
	public ArrayList<ProductInventory> getAllExpiredItems() {

		Date date = new Date(System.currentTimeMillis());

		for (ProductInventory item : allItemList) {
			if (item.getExpirationDate().compareTo(date) < 0) {
				expiredItemList.add(item);
			}
		}
		return expiredItemList;
	}

	public Boolean removeAllExpiredItems() {
		Boolean removeAllExpiredItemsSuccess = false;
		expiredItemList = new ArrayList<ProductInventory>();

		IProductInventory item = new ProductInventory();

		try {
			expiredItemList = getAllExpiredItems();

			for (ProductInventory inputItem : expiredItemList) {
				item.removeItemsFromInventory(inputItem.getItemId(), 1);
			}
			removeAllExpiredItemsSuccess = true;

		} catch (Exception e) {
		}

		return removeAllExpiredItemsSuccess;
	}

}
