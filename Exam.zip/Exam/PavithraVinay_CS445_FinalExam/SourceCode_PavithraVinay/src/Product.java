import java.util.ArrayList;

public class Product implements IProductOperations {
	private int productId;
	private String name;
	private ProductCategory category;
	private int maxQuantity; // To store threshold value
	private int minQuantity; // To store threshold value
	private int actualQuantity;
	private Boolean isFavorite;
	private ProductStatus status; // Enum
	// Since no database for demo purpose, we will be using productList as our
	// data source;
	private ArrayList<Product> productList;

	// Use add product method. Initializing only empty product.
	public Product() {
		productList = new ArrayList<Product>();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		// If Invalid ProductId throw exception
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		// If invalid name throw exception; Should be valid alphanumeric
		// characters
		// if(productList.contains(name)){
		// //Return product already exists
		// }

		this.name = name;
	}

	public ProductCategory getCategory() {
		return category;
	}

	public void setCategory(ProductCategory category) {
		// If invalid category throw exception;
		this.category = category;
	}

	public int getMaxQuantity() {
		return maxQuantity;
	}

	public void setMaxQuantity(int maxQuantity) {
		// If invalid throw exception
		this.maxQuantity = maxQuantity;
	}

	public int getMinQuantity() {
		return minQuantity;
	}

	public void setMinQuantity(int minQuantity) {
		// If invalid quantity throw exception;
		this.minQuantity = minQuantity;
	}

	public int getActualQuantity() {
		return actualQuantity;
	}

	public void setActualQuantity(int actualQuantity) {
		// If(InvalidQuantity) like zero or negative number
		// Throw exception
		if (actualQuantity + this.actualQuantity > this.maxQuantity) {
			// Throw exception("Cannot exceed max quantity for this product")
		}

		this.actualQuantity = actualQuantity;
	}

	public Boolean getIsFavorite() {
		return isFavorite;
	}

	public void setIsFavorite(Boolean isFavorite) {
		this.isFavorite = isFavorite;
	}

	public ProductStatus getStatus() {
		return status;
	}

	public void setStatus(ProductStatus status) {
		this.status = status;
	}

	// public Item getItem() {
	// return item;
	// }

	public ArrayList<Product> getProductList() {
		return productList;
	}

	public void setProductList(ArrayList<Product> productList) {
		this.productList = productList;
	}

	public boolean addNewProduct(Product product, int quantity) {
		boolean addProductSuccess = false;

		try {
			setActualQuantity(quantity);

			// Setters will validate each of individual fields being added and
			// will return error/exception if any field is invalid
			productList.add(product);
			addProductSuccess = true;
		} catch (Exception e) {
			// Exceptionhandling
		}

		return addProductSuccess;
	}

	@Override
	public boolean updateQuantity(int productId, int quanitty) {
		// TODO Auto-generated method stub
		return false;
	}

}
