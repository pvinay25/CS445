import java.util.ArrayList;

public interface IExpiredProduct {
	ArrayList<ProductInventory> getAllExpiredItems();
	Boolean removeAllExpiredItems();
}
