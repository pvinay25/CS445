
public class ProductCategory {
	private int categoryId;
	private String categoryName;	
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		//Check if valid categoryId; if not throw exception;
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		if(categoryName.isEmpty() || categoryName == null){
			//return InvalidCategoryException;
		}			
		this.categoryName = categoryName;
	}
	
	
}
