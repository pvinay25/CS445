
public interface IProductOperations {
	boolean addNewProduct(Product product, int quantity);
	boolean updateQuantity(int productId, int quanitty);
}
