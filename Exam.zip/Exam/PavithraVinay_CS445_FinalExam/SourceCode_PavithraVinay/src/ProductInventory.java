import java.sql.Date;
import java.util.ArrayList;

public class ProductInventory implements IProductInventory {
	
	private int _itemId;
	private int _productId;
	private Date _expirationDate;
	
	//Using arraylist as datastore since there is no database for demo purposes
	private ArrayList<ProductInventory> itemList;
	
	public ProductInventory()
	{
		
	}

	public int getItemId() {
		return _itemId;
	}

	public void setItemId(int itemId) {
		this._itemId = itemId;
	}

	public Date getExpirationDate() {
		return _expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		Date date = new Date(System.currentTimeMillis());
		if(expirationDate.compareTo(date) <0 ){
			//Return error saying expiration date cannot be in past;
		}
		this._expirationDate = expirationDate;
	}
	
	public int getProductId() {
		return _productId;
	}

	public void setProductId(int productId) {
		this._productId = productId;
	}

	public ArrayList<ProductInventory> retrieveAllItems(){
		return this.itemList;
	}

	
	//returns new ItemId;
	private int getNewItemId(){
		return this._itemId +1;
	}

	
	public boolean addItemsToInventory(int productId, int quantity, Date expirationDate) {
		
		boolean addItemSuccess = false;
		
		try{		
			Product product = new Product();
			ProductInventory item = new ProductInventory();
			item._itemId = getNewItemId();
			setProductId(productId);
			item._productId = getProductId();
			setExpirationDate(expirationDate);
			item._expirationDate = getExpirationDate();
			itemList.add(item); //Itemlist should be initialized before adding;
			product.updateQuantity(productId, quantity);
			
			addItemSuccess = true;
		}
		catch(Exception e){
			//Exception handling
		}
		return addItemSuccess;
	}
	
	public boolean removeItemsFromInventory(int itemId, int quantity) {
		boolean removeItemsSuccess = false;
		int position = -1;
		
		try{
			for(int i=0;i<itemList.size();i++){
				if(itemId == itemList.get(i)._itemId){
					position = i;
					break;
				}
			}
			if(position<0){
				//Return error indicating Product not found;
				return removeItemsSuccess;
			}
			
			int productId = itemList.get(position)._productId;
			
			itemList.remove(position);
			
			IProductOperations product = new Product();
			product.updateQuantity(productId, -1); //Update the actual count in Product
			removeItemsSuccess=true;
			
		}catch (Exception e){
			//Exception handling
		}
		
		return removeItemsSuccess;
	}

	@Override
	public boolean consumeItemsFromInventory(int productId, int quantity) {
		
		return false;
	}

	@Override
	public boolean removeItemsFromInventory(int itemId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<ProductInventory> retrieveThresholdItems() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
