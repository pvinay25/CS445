create sequence cid_seq start with 1 increment by 1 nocache;

CREATE TABLE Customer
(
    cID integer PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL    
);

CREATE OR REPLACE TRIGGER cust_trig
BEFORE INSERT
ON Customer
FOR EACH ROW
BEGIN
:NEW.cID:=cid_seq.NEXTVAL;
END;


commit;


select * from Customer;
desc customer;
INSERT INTO Customer(name, email, password) VALUES('Bob', 'b@b.com', 'password');


ALTER TABLE Customer ADD status NUMBER;