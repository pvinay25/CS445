create sequence rid_seq start with 1 increment by 1 nocache;


CREATE TABLE Item
(
    rID NUMBER PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price FLOAT NOT NULL,
    url VARCHAR(100) NOT NULL,
    description VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL    
);


CREATE OR REPLACE TRIGGER item_trig
BEFORE INSERT
ON Item
FOR EACH ROW
BEGIN
:NEW.rID:=rid_seq.NEXTVAL;
END;


create sequence ord_id_seq start with 1 increment by 1 nocache;

CREATE TABLE Orders
(
    order_number INTEGER PRIMARY KEY,
    cID INTEGER, 
    total_price FLOAT NOT NULL,
    status VARCHAR(100) NOT NULL,
    address VARCHAR(100) NOT NULL,
    summary VARCHAR(100) NOT NULL,
    FOREIGN KEY(cID) REFERENCES Customer(cID)
);

CREATE OR REPLACE TRIGGER order_trig
BEFORE INSERT
ON Orders
FOR EACH ROW
BEGIN
:NEW.order_number:=ord_id_seq.NEXTVAL;
END;

commit;

CREATE TABLE Cart
(
    cID INTEGER REFERENCES Customer(cID),
    rID INTEGER REFERENCES Item(rID),
    quantity INTEGER    
);

select * from Item;
desc Item;
Alter table Item modify url VARCHAR(700);
COMMIT;
INSERT INTO Item(name, price, url, description, category) VALUES('Brackets', 100.45,
            'http://www.bhphotovideo.com/images/images2500x2500/Vello_CB_200_Speedy_Camera_Bracket_743039.jpg','camera accessory - bracket','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Cables', 50.85,
            'http://survivaldealer.com/zencart/images/ca-25-50-100-150.jpg','camera accessory - cables','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Connectors', 90.56,
            'http://www.amssecurity.in/images/cctv-camera-connector-pack.jpg','camera accessory - connectors','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Housings', 178.45,
            'http://g02.a.alicdn.com/kf/HTB1vCXkIXXXXXbJXpXXq6xXFXXXO/Plastic-cctv-camera-housing-enclosure.jpg','camera accessory - housings','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Infrared Lighting', 120.99  ,
            'http://thumbs2.ebaystatic.com/d/l225/m/mdmQSoqU71BjZXwZwd7UwLA.jpg','camera accessory - IL','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Lenses', 500.45,
            'http://icdn9.digitaltrends.com/image/digital-camera-lenses-660x360.jpg?ver=25','camera accessory - lenses','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Microphones', 167.99,
            'http://i01.i.aliimg.com/img/pb/976/264/397/397264976_691.JPG','camera accessory - Microphones','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Monitors', 450.78,
            'http://www.bhphotovideo.com/images/images2500x2500/elvid_rvm_7b_alt_7_lightweight_advanced_on_1037011.jpg','camera accessory - Monitors','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('Power Supplies', 700.56,
            'http://www.personalarms.com/surveillance/images/PS-604_609_616.jpg','camera accessory - Power Supplies','Accessories');
INSERT INTO Item(name, price, url, description, category) VALUES('IP Surveillance Cameras', 1100.00,
            'http://icdn4.digitaltrends.com/image/invite-big-brother-into-your-home-with-the-latest-foolproof-security-cameras-header-1500x991.jpg',
            'camera accessory - IP Surveillance Cameras','Security Cameras');            
INSERT INTO Item(name, price, url, description, category) VALUES('Digital Surveillance Cameras', 2800.56,
            'http://www.teledair.com/wp-content/uploads/2013/03/security_domecamera.jpg','camera accessory - Digital Surveillance Cameras','Security Cameras');
INSERT INTO Item(name, price, url, description, category) VALUES('Analog Security Cameras', 3000.56,
            'http://pro.jvc.com/pro/attributes/CCTV/photos/general/TKC9200UHR.jpg','camera accessory - Analog Security Cameras','Security Cameras');
INSERT INTO Item(name, price, url, description, category) VALUES('Analog DVR', 800.98,
            'http://www.dahuasecurity.com/upfiles/201308807420501.jpg','camera accessory - Analog DVR','DVRs');
INSERT INTO Item(name, price, url, description, category) VALUES('Digital DVRs', 900.56,
            'http://www.cctvcamerapros.com/v/vspfiles/photos/DVR-H264-4E-2.jpg','camera accessory - Digital DVRs','DVRs');
INSERT INTO Item(name, price, url, description, category) VALUES('Hybrid DVRs', 4000.06,
            'http://i00.i.aliimg.com/img/pb/310/900/448/448900310_850.jpg','camera accessory - Hybrid DVRs','DVRs');
            
select * from customer;
select * from Cart; 
select * from Item;
select * from Orders;

commit;

--UPDATE Item SET description='Security Cameras - IP Surveillance Cameras' where rid = 10;
--UPDATE Item SET description='Security Cameras - Digital Surveillance Cameras' where rid = 11;
--UPDATE Item SET description='Security Cameras - Analog Security Cameras' where rid = 12;
--UPDATE Item SET description='DVRs - Analog DVR' where rid = 13;
--UPDATE Item SET description = 'DVRs - Digital DVR' where rid = 14;
--UPDATE Item SET description = 'DVRs - Hybrid DVR' where rid = 15;
select * from  cart;
select * from item;
INSERT INTO Orders(cid, total_price, status,address, summary) VALUES(2, 45.67, 'Ready to ship', '300 Inwood Dr, Wheeling, Chicago IL',
'this item is sold exclusively on our website');
INSERT INTO cart (cid, rid, quantity) VALUES (2, 10, 1);
INSERT INTO cart (cid, rid, quantity) VALUES (2, 5, 3);
INSERT INTO cart (cid, rid, quantity) VALUES (2, 12, 10);
INSERT INTO cart (cid, rid, quantity) VALUES (2, 8, 1);
select cID,name,i.rID,quantity from Cart c INNER JOIN Item i ON c.rID = i.rID where cID=2;
commit;

select * from customer;
ALTER TABLE customer DROP COLUMN status;


        
            

